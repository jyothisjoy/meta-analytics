<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');  // replace with your DB username
define('DB_PASS', '');      // replace with your DB password
define('DB_NAME', 'meta'); // replace with your DB name 